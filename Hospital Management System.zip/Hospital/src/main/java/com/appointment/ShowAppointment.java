package com.appointment;



import jakarta.servlet.RequestDispatcher;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.apache.catalina.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;



/**
 * Servlet implementation class RegistrationServlet
 */
public class ShowAppointment extends HttpServlet {
	
	private static String DB_URL = "jdbc:mysql://localhost:3306/hospital";
    private static String DB_USER = "root";
    private static String DB_PASSWORD = "Pass@mysql";

       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String contact = request.getParameter("contact");
//		int age = Integer.parseInt(request.getParameter("age"));
//		
//		String contact = request.getParameter("contact");
//		String email = request.getParameter("email");
//		String treatment = request.getParameter("treatment");
		
		
		
		PrintWriter pout = response.getWriter();
		response.setContentType("text/html");
		
//		pout.print("Name : "+name);
//		pout.print("Age  : "+age);
		
		try {
			// load driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			// connection with db
			Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
			
			// creating insert query
//			String insertQuery = "INSERT INTO appointment (p_name,p_age,p_contact,p_email, problem ) values(? , ?, ?, ?, ?, ?);";
//			PreparedStatement psobj = con.prepareStatement(insertQuery);
//			psobj.setString(1, name);
//			psobj.setInt(2, age);
//			psobj.setString(3, contact);
//			psobj.setString(4, email);
//			psobj.setString(5, treatment);
			Statement stmt = con.createStatement();
			
//			
//			psobj.executeUpdate();
//			
//			pout.print("Hello "+name+" , Appointment Booked Successfully !");
//			
//			String showQuery = "SELECT * FROM appointment where p_contact= ?;";
//			PreparedStatement psobj2 = con.prepareStatement(showQuery);
//			psobj2.setString(1, contact);
//			psobj2.executeUpdate();
//			
//			ResultSet resultSet = stmt.executeQuery(showQuery);
			
			
			
			request.getRequestDispatcher("home.jsp").forward(request, response);
			
//			RequestDispatcher dispatcher = request.getRequestDispatcher("/appointments.jsp");
//			dispatcher.forward(request, response);
			
			con.close();
			
			
			
		}catch(Exception e) {
			System.out.println("Exception "+e);
			
		}
	}

}