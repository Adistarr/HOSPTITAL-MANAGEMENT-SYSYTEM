package com.appointment;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Servlet implementation class RegistrationServlet
 */
public class RemoveAppo extends HttpServlet {
	
	private static String DB_URL = "jdbc:mysql://localhost:3306/hospital";
    private static String DB_USER = "root";
    private static String DB_PASSWORD = "Pass@mysql";

       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("name");
		int age = Integer.parseInt(request.getParameter("age"));
		
		String contact = request.getParameter("contact");
		String email = request.getParameter("email");
		String problem = request.getParameter("treatment");
		
		
		
		PrintWriter pout = response.getWriter();
		response.setContentType("text/html");
		
//		pout.print("Name : "+name);
//		pout.print("Age  : "+age);
		
		try {
			// load driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			// connection with db
			Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
			
			// creating insert query
			String insertQuery = "TRUNCATE TABLE appointment";
			PreparedStatement psobj = con.prepareStatement(insertQuery);
			
			psobj.executeUpdate();
			
			pout.print("Appointment Deleted Successfully !");
			
//			String showQuery = "SELECT patient_id, p_name, p_email from appointment;";
//			PreparedStatement psobj2 = con.prepareStatement(showQuery);
//			psobj2.executeUpdate();
			
			con.close();
			
			
			
		}catch(Exception e) {
			System.out.println("Exception "+e);
			
		}
	}

}
