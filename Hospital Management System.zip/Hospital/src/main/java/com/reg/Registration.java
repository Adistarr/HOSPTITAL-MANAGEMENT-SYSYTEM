package com.reg;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Servlet implementation class RegistrationServlet
 */
public class Registration extends HttpServlet {
	
	private static String DB_URL = "jdbc:mysql://localhost:3306/hospital";
    private static String DB_USER = "root";
    private static String DB_PASSWORD = "Pass@mysql";
//    private static String T_NAME = "portaluser";
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("name");
		int age = Integer.parseInt(request.getParameter("age"));
		String address = request.getParameter("address");
		String contact = request.getParameter("contact");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		
		
		PrintWriter pout = response.getWriter();
		response.setContentType("text/html");
		
//		pout.print("Name : "+name);
//		pout.print("Age  : "+age);
		
		try {
			// load driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			// connection with db
			Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
			
			// creating insert query
			String insertQuery = "INSERT INTO user (user_name,age,address,contact,email, password ) values(? , ?, ?, ?, ?, ?);";
			PreparedStatement psobj = con.prepareStatement(insertQuery);
			psobj.setString(1, name);
			psobj.setInt(2, age);
			psobj.setString(3, address);
			psobj.setString(4, contact);
			psobj.setString(5, email);
			psobj.setString(6, password);
			
			
			psobj.executeUpdate();
			
			pout.print("Hello "+name+" , Your Registration is Done Successfully !");
			
			
			con.close();
			
			
			
		}catch(Exception e) {
			System.out.println("Exception "+e);
			
		}
	}

}
