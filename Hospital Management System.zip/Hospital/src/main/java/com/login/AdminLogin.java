package com.login;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Servlet implementation class LoginServlet
 */
public class AdminLogin extends HttpServlet {
	
	// DB -- JDBC URL, User and Password
    private static String DB_URL = "jdbc:mysql://localhost:3306/hospital";
    private static String DB_USER = "root";
    private static String DB_PASSWORD = "Pass@mysql";
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String email = request.getParameter("username");
		String password = request.getParameter("password");
		String contact = request.getParameter("username");
		PrintWriter pout = response.getWriter();
		response.setContentType("text/html");
		
		
        
		try {
			// load driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			// connection with db
			Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
			
			// creating query
			String selectQuery = "SELECT * FROM admin WHERE (admin_email = ?  or admin_contact = ? )AND password = ?";
			
			PreparedStatement psobj = con.prepareStatement(selectQuery);
			psobj.setString(1, email);
			psobj.setString(2, contact);
			psobj.setString(3, password);
			
			ResultSet resultSet = psobj.executeQuery();
			
			 if (resultSet.next()) {
	                // Successful login, redirect to a welcome page or dashboard
//	                response.sendRedirect("userProfile.jsp");
				 	pout.print("<h1>Login Successfully !</h1>");
				 	response.sendRedirect("admin_home.jsp");
	            } else {
	                // Invalid credentials, display an error message
	                
	            	pout.print("<h1>Enter correct Passoword or ID</h1>");
	            }
		
		}catch(Exception e) {
			System.out.println("Exception "+e);
			
		}
		
		
		// DB connectivity
//		String dbUsername = "Hrishi1234";
//		String dbPassword = "Hrishi@1234";
//		
//		if(username.equals(dbUsername) && password.equals(dbPassword)) {
//			pout.print("<h1>Login Successfully !</h1>");
//		}else {
//			pout.print("<h1>Enter correct Passoword or ID</h1>");
//		}
	}

}
